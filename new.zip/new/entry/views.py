from django.shortcuts import render, redirect, HttpResponse
from datetime import datetime,timedelta,date
# Create your views here.

from .models import isbn, roll, Transfer
from .models import transaction, issuedetails
from .forms import BookForm #, TransactionForm
from . import models, forms

objm = issuedetails()

def index(request):

    #form = EntryForm()

    #context = {'form' : form}

    #return render(request, 'index.html', context)
    return render(request, 'index.html')

def findcareerone(request):
    firstint = request.GET['first']
    if (firstint == "Coding"):
        return render(request,'showcoding.html',{'Video': models.Coding.objects.all()})
        #obj = models.Coding.objects.values_list('name', 'resource')
        #for ob in obj:
        #print(obj)
    elif(firstint=="Data Analysis"):
        return render(request,'showdataanalysis.html',{'Video': models.DataAnalysis.objects.all()})
    if(firstint=="Research"):
        return render(request,'showresearch.html',{'Video': models.Research.objects.all()}) 
    return redirect('index')

"""
def findcareertwo(request):
    secondint = request.GET['second']
    if (secondint == "Coding"):
        return render(request,'showcoding.html',{'Video': models.Coding.objects.all()})
        #obj = models.Coding.objects.values_list('name', 'resource')
        #for ob in obj:
        #print(obj)
    elif(secondint=="Data Analysis"):
        return render(request,'showdataanalysis.html',{'Video': models.DataAnalysis.objects.all()})
    elif(secondint=="Research"):
        return render(request,'showresearch.html',{'Video': models.Research.objects.all()}) 
    return redirect('index')

def findcareerthird(request):
    thirdint = request.GET['third']
    if (thirdint == "Coding"):
        return render(request,'showcoding.html',{'Video': models.Coding.objects.all()})
        #obj = models.Coding.objects.values_list('name', 'resource')
        #for ob in obj:
        #print(obj)
    elif(thirdint=="Data Analysis"):
        return render(request,'showdataanalysis.html',{'Video': models.DataAnalysis.objects.all()})
    elif(thirdint=="Research"):
        return render(request,'showresearch.html',{'Video': models.Research.objects.all()}) 
    return redirect('index')
"""

def contact(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        msg = request.POST['comment']
        
        contact = models.Contact(name=name, email=email, message=msg)
        contact.save()
        return redirect('contact')
    allPost = models.Contact.objects.all()[::-1]
    context = {'allPost':allPost}
    
    return render(request, 'contact.html', context)

def findint(request):
    return render(request, 'findint.html')
    
def addbook(request):
    form=forms.BookForm()
    if request.method=='POST':
        #now this form have data from html
        form=forms.BookForm(request.POST)
        if form.is_valid():
            user=form.save()

            
            #obj2=models.issuedetails()
            objm.book=user.name
            objm.save()
            
            return render(request,'bookadded.html')
    return render(request,'addbook.html',{'form':form})

def addstudent(request):
    form=forms.StudentForm()
    if request.method=='POST':
        #now this form have data from html
        form=forms.StudentForm(request.POST)
        if form.is_valid():
            user=form.save()
            
            #obj2=models.issuedetails()
            objm.stname=user.name
            objm.save()
            
            return render(request,'studentadded.html')
    return render(request,'addstudent.html',{'form':form})

def viewbook(request):
    books=models.Book.objects.all()
    return render(request,'viewbook.html',{'books':books})

def viewstudent(request):
    students=models.Student.objects.all()
    return render(request,'viewstudent.html',{'students':students})

def issuebook(request):
    form=forms.IssuedBookForm()
    if request.method=='POST':
        #now this form have data from html
        form=forms.IssuedBookForm(request.POST)
        if form.is_valid():
            obj=models.IssuedBook()
            obj.enrollment=request.POST.get('enrollment2')
            obj.isbn=request.POST.get('isbn2')
            obj.save()
            
            books = models.Book.objects.filter(isbn=obj.isbn)    
            for book in books:
                book.count-=1
                book.save()
            print("hellloooooo") 
            
            #transfers = models.transaction.objects.all()
            #form=forms.TransactionForm()
            #if form.is_valid():
            
            obj2=models.transaction()
            obj2.isbn=obj.isbn
            obj2.enrollment=obj.enrollment
            obj2.save()
            
            return render(request,'bookissued.html')
    return render(request,'issuebook.html',{'form':form})

def viewissuedbook(request):
    issuedbooks=models.IssuedBook.objects.all()
    li=[]
    for ib in issuedbooks:
        issdate=str(ib.issuedate.day)+'-'+str(ib.issuedate.month)+'-'+str(ib.issuedate.year)
        expdate=str(ib.expirydate.day)+'-'+str(ib.expirydate.month)+'-'+str(ib.expirydate.year)
        #fine calculation
        days=(date.today()-ib.issuedate)
        print(date.today())
        d=days.days
        """
        fine=0
        if d>15:
            day=d-15
            fine=day*10
        """

        books=list(models.Book.objects.filter(isbn=ib.isbn))
        students=list(models.Student.objects.filter(enrollment=ib.enrollment))
        i=0
        for l in books:
            t=(students[i].name,students[i].enrollment,books[i].name,books[i].author,issdate,expdate)
            i=i+1
            li.append(t)
    """        
    books = models.Book.objects.filter(isbn=50)    
    for book in books:
        book.name="newww one"
        book.save()
    print("heyyy")  
    """
    return render(request,'viewissuedbook.html',{'li':li})


def deletebook(request):
    bookname = request.GET['name']
    obj = models.Book.objects.filter(name=bookname).delete()
    return redirect('index')

def searchbook(request):
    authorname = request.GET['name']
    obj = models.Book.objects.all().filter(author=authorname)
    context = {'obj' : obj, 'authorname':authorname}
    return render(request, 'searchbooks.html', context)

def searchstudent(request):
    isbn = request.GET['name']
    obj = models.IssuedBook.objects.all().filter(isbn=isbn)
    print(obj)
    context = {'obj' : obj, 'isbn':isbn}
    #return redirect('index')
    return render(request, 'searchstudent.html', context)

def deletestudent(request):
    stname = request.GET['name']
    obj = models.Student.objects.filter(name=stname).delete()
    return redirect('index')


def findcopies(request):
    book = request.GET['name']
    obj = models.Book.objects.all().filter(name=book)
    #print(obj[1])
    context = {'obj' : obj, 'book':book}
    return render(request, 'showuser.html', context)